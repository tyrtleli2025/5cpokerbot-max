'''
The Counter-Punch Bot (Replicating Bot B)
'''
from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction, DiscardAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot

class Player(Bot):
    '''
    A bot that plays tight pre-flop against aggression, 
    but value bets strong hands post-flop.
    '''

    def __init__(self):
        pass

    def handle_new_round(self, game_state, round_state, active):
        pass

    def handle_round_over(self, game_state, terminal_state, active):
        pass

    def get_action(self, game_state, round_state, active):
        legal = round_state.legal_actions()
        street = round_state.street
        my_cards = round_state.hands[active]
        board = round_state.board
        my_pip = round_state.pips[active]
        opp_pip = round_state.pips[1-active]

        # ---------------------------------------------------------
        # 1. HANDLE DISCARD PHASE (Street 1 & 2)
        # ---------------------------------------------------------
        # If it's the discard round...
        if street == 1 or street == 2:
            # If we CAN discard, we MUST discard
            if DiscardAction in legal:
                return self.get_best_discard(my_cards)
            
            # If we can't discard, we are waiting for opponent. MUST CHECK.
            return CheckAction()

        # ---------------------------------------------------------
        # 2. PRE-FLOP STRATEGY (Street 0)
        # ---------------------------------------------------------
        if street == 0:
            # Check if opponent went All-In (or raised huge)
            pot_odds_are_bad = (opp_pip > 10) 

            if pot_odds_are_bad:
                # ONLY Call if we have a premium hand
                if self.is_premium(my_cards):
                    return CallAction()
                else:
                    return FoldAction()
            
            # If it's cheap (limped pot), just Check/Call to see the flop
            if CheckAction in legal:
                return CheckAction()
            return CallAction()

        # ---------------------------------------------------------
        # 3. POST-FLOP STRATEGY (Street 3, 4, 5)
        # ---------------------------------------------------------
        # Simple "Honest" Poker: If we have a pair or better, Bet/Call.
        # If we have nothing, Check/Fold.
        
        strength = self.evaluate_strength(my_cards, board)
        
        # If we have a Pair (strength >= 1) or good High Card
        if strength >= 1.0:
            # Value Bet if checked to us
            if CheckAction in legal:
                # If we have a strong hand, maybe bet small? 
                # For safety/replication, checking is fine, but let's Raise if monster
                if strength >= 2.0 and RaiseAction in legal: # Trips/Straight
                     min_r, max_r = round_state.raise_bounds()
                     return RaiseAction(min_r)
                return CheckAction()
            # Call if bet into
            return CallAction()
        
        # Weak Hand
        if CheckAction in legal:
            return CheckAction()
        return FoldAction()

    # ---------------------------------------------------------
    # HELPER FUNCTIONS
    # ---------------------------------------------------------

    def get_rank(self, card_str):
        # Maps 2-9, T, J, Q, K, A to 0-12
        ranks = "23456789TJQKA"
        return ranks.index(card_str[0])

    def is_premium(self, cards):
        ''' Returns True for Pairs, or High Cards (A, K, Q) '''
        ranks = [self.get_rank(c) for c in cards]
        
        # Check for Pair
        if len(set(ranks)) < 3: 
            return True
        
        # Check for High Cards (Ace=12, King=11, Queen=10)
        # Bot B was calling with K-high and A-high
        if max(ranks) >= 10: 
            return True
            
        return False

    def get_best_discard(self, cards):
        ''' Discards the lowest unpaired card '''
        ranks = [self.get_rank(c) for c in cards]
        
        # If we have a pair, discard the kicker (the card that isn't the pair)
        counts = {r: ranks.count(r) for r in ranks}
        for r, count in counts.items():
            if count == 2:
                # Find the card that is NOT this rank
                for i, card_rank in enumerate(ranks):
                    if card_rank != r:
                        return DiscardAction(i)

        # If no pair, discard the lowest card
        min_rank = min(ranks)
        discard_idx = ranks.index(min_rank)
        return DiscardAction(discard_idx)

    def evaluate_strength(self, my_cards, board):
        ''' 
        Returns a float score:
        0 = High Card
        1 = Pair
        2 = Two Pair / Trips / Straight / Flush
        '''
        all_cards = my_cards + board
        ranks = [self.get_rank(c) for c in all_cards]
        suits = [c[1] for c in all_cards]
        
        # Check Flush (3 suits same) - (This game is 3-card poker logic roughly)
        for s in "scdh":
            if suits.count(s) >= 3:
                return 3.0 # Flush
        
        # Check Trips
        counts = {r: ranks.count(r) for r in ranks}
        if 3 in counts.values():
            return 3.0 # Trips
            
        # Check Straight (Simplified)
        unique_ranks = sorted(list(set(ranks)))
        if len(unique_ranks) >= 3:
            for i in range(len(unique_ranks)-2):
                if unique_ranks[i+2] - unique_ranks[i] == 2:
                    return 2.5 # Straight
        
        # Check Pair
        if 2 in counts.values():
            return 1.0 # Pair
            
        return 0.0 # High Card

if __name__ == '__main__':
    run_bot(Player(), parse_args())