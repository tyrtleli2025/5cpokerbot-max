'''
Trap Premium / Raise Decent (Fold to 3-Bet) / Fold Bad Bot
'''
from skeleton.actions import FoldAction, CallAction, CheckAction, RaiseAction, DiscardAction
from skeleton.states import GameState, TerminalState, RoundState
from skeleton.bot import Bot
from skeleton.runner import parse_args, run_bot

class Player(Bot):
    '''
    Strategy:
    1. Pre-flop: 
       - Premium Hands (AA, KK, etc.) -> Call (Trap/Slowplay)
       - Decent Hands (Pairs, Suited, High Cards) -> Raise 5x BB. 
         **CRITICAL FIX:** If opponent raises > 5x BB (3-bet/Shove), we FOLD these.
       - Bad Hands -> Fold (or Check if free)
    2. Post-flop:
       - Connect (Pair+) -> Bet Pot
       - Miss -> Check/Fold
    '''

    def __init__(self):
        # Rank map for numerical comparison: 2=0, ... A=12
        self.rank_map = {r: i for i, r in enumerate("23456789TJQKA")}
        self.STARTING_STACK = 400
        self.BIG_BLIND = 2

    def handle_new_round(self, game_state, round_state, active):
        pass

    def handle_round_over(self, game_state, terminal_state, active):
        pass

    def get_action(self, game_state, round_state, active):
        legal = round_state.legal_actions()
        street = round_state.street
        my_cards = round_state.hands[active]
        board = round_state.board
        my_pip = round_state.pips[active]
        opp_pip = round_state.pips[1-active]

        # ---------------------------------------------------------
        # 1. HANDLE DISCARD ACTION
        # ---------------------------------------------------------
        if DiscardAction in legal:
            return self.get_discard_action(my_cards)

        # ---------------------------------------------------------
        # 2. PRE-FLOP STRATEGY
        # ---------------------------------------------------------
        if street == 0:
            # A. PREMIUM HANDS -> CALL (TRAP)
            if self.is_premium(my_cards):
                if CallAction in legal:
                    return CallAction()
                if CheckAction in legal:
                    return CheckAction()
                # If we somehow can't call or check (e.g. forced raise?), take min raise
                if RaiseAction in legal:
                    return RaiseAction(round_state.raise_bounds()[0])

            # B. DECENT HANDS -> RAISE 5x BB (But Fold to Aggression)
            elif self.is_decent_hand(my_cards):
                target_amount = 5 * self.BIG_BLIND # 10 chips
                
                # SAFETY CHECK: 
                # If the opponent has already bet more than our target (e.g. 3-bet to 20 or All-in),
                # we consider this hand too weak to call that price.
                if opp_pip > target_amount:
                     if CheckAction in legal: return CheckAction()
                     return FoldAction()

                # If the price is cheap, try to Raise to 10
                if RaiseAction in legal:
                    min_raise, max_raise = round_state.raise_bounds()
                    
                    if min_raise <= target_amount <= max_raise:
                        return RaiseAction(target_amount)
                    elif target_amount < min_raise:
                         # We can't raise to 10 because min_raise is higher (but likely < opp_pip checks above).
                         # We just Call the cheap-ish amount.
                         if CallAction in legal: return CallAction()
                    elif target_amount > max_raise:
                        return RaiseAction(max_raise)
                
                # If we can't raise, Call (only if cheap, which logic above ensures)
                if CallAction in legal:
                    return CallAction()

            # C. BAD HANDS -> FOLD (Or Check if free)
            else:
                if CheckAction in legal:
                    return CheckAction()
                return FoldAction()

        # ---------------------------------------------------------
        # 3. POST-FLOP STRATEGY (Bet Pot if connected, Check/Fold if not)
        # ---------------------------------------------------------
        connected = self.has_connected(my_cards, board)

        if connected:
            # BET POT LOGIC
            if RaiseAction in legal:
                min_raise, max_raise = round_state.raise_bounds()
                current_pot = (self.STARTING_STACK * 2) - sum(round_state.stacks)
                
                # Pot-sized raise calculation
                raise_amount = opp_pip + current_pot
                actual_raise = min(max(min_raise, raise_amount), max_raise)
                return RaiseAction(actual_raise)
            
            if CallAction in legal:
                return CallAction()

        # IF WE DID NOT CONNECT: Check or Fold
        if CheckAction in legal:
            return CheckAction()
        
        return FoldAction()

    # ---------------------------------------------------------
    # HELPER FUNCTIONS
    # ---------------------------------------------------------
    def get_discard_action(self, cards):
        '''Discard card to keep strongest 2-card Hold'em hand.'''
        best_score = -1
        discard_index = 0
        for i in range(len(cards)):
            kept_cards = cards[:i] + cards[i+1:]
            score = self.rate_2card_hand(kept_cards)
            if score > best_score:
                best_score = score
                discard_index = i
        return DiscardAction(discard_index)

    def rate_2card_hand(self, cards):
        r1, r2 = self.rank_map[cards[0][0]], self.rank_map[cards[1][0]]
        s1, s2 = cards[0][1], cards[1][1]
        score = max(r1, r2)
        if r1 == r2: score += 100
        if s1 == s2: score += 10
        if abs(r1 - r2) == 1: score += 5
        return score

    def is_premium(self, cards):
        '''
        Returns True if hand is "Premium" (Trap worthy).
        Criteria: Pairs 10-10 or better, or Trip Aces/Kings.
        '''
        ranks = [self.rank_map[c[0]] for c in cards]
        counts = {r: ranks.count(r) for r in ranks}
        
        # High Pairs (10, J, Q, K, A) -> Ranks 8, 9, 10, 11, 12
        for r, count in counts.items():
            if count >= 2 and r >= 8: # 10 is index 8
                return True
        return False

    def is_decent_hand(self, cards):
        '''
        Returns True if hand is "Decent" (Raise worthy).
        Criteria: Any Pair, Any Suited, or High Cards.
        '''
        ranks = [self.rank_map[c[0]] for c in cards]
        suits = [c[1] for c in cards]
        
        # Pairs (that aren't premium, though if we check here first, it covers all pairs)
        if len(set(ranks)) < 3:
            return True
        # Suited
        if len(set(suits)) < 3:
            return True
        # High Cards (Sum >= 15)
        if sum(ranks) >= 15:
            return True
        return False

    def has_connected(self, my_cards, board):
        '''Returns True if we hit the board (Pair or better).'''
        my_ranks = [self.rank_map[c[0]] for c in my_cards]
        board_ranks = [self.rank_map[c[0]] for c in board]
        
        for r in my_ranks:
            if r in board_ranks:
                return True
        if my_ranks[0] == my_ranks[1]:
            return True
        return False

if __name__ == '__main__':
    run_bot(Player(), parse_args())